﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiddlewareChevyStar.Models
{
    public class METERDATA
    {
        public string ASSETNUM { get; set; }

        public string METERNAME { get; set; }

        public double NEWREADING { get; set; }

        public string SITEID { get; set; }
    }
}
